# ============================================================
#  llm/client.py — vLLM client (OpenAI-compatible)
# ============================================================

import os
from langchain_openai import ChatOpenAI
from config import (
    VLLM_BASE_URL, VLLM_API_KEY, VLLM_MODEL, LLM_TEMPERATURE,
    LANGSMITH_ENABLED, LANGSMITH_PROJECT
)

# --- LangSmith (اختياري) ---
if LANGSMITH_ENABLED:
    os.environ.setdefault("LANGSMITH_TRACING", "true")
    os.environ.setdefault("LANGSMITH_ENDPOINT", "https://api.smith.langchain.com")
    os.environ.setdefault("LANGSMITH_PROJECT",   LANGSMITH_PROJECT)
    api_key = os.environ.get("LANGSMITH_API_KEY", "")
    if not api_key:
        print("[WARNING] LANGSMITH_ENABLED=True لكن LANGSMITH_API_KEY مش متحط")


def get_llm(temperature: float = LLM_TEMPERATURE) -> ChatOpenAI:
    """
    يرجع LLM client متوصل بـ vLLM.
    vLLM بيدعم OpenAI-compatible API فمش محتاجين library خاصة.
    """
    return ChatOpenAI(
        base_url    = VLLM_BASE_URL,
        api_key     = VLLM_API_KEY,
        model       = VLLM_MODEL,
        temperature = temperature,
        streaming   = False,
    )


def get_llm_with_tools(tools: list, temperature: float = LLM_TEMPERATURE) -> ChatOpenAI:
    """LLM مع tools مربوطة — للـ Researcher"""
    return get_llm(temperature).bind_tools(tools)
