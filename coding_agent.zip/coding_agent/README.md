# 🤖 Coding Agent v2.0
### LangGraph + vLLM + Docker Sandbox

---

## ما هو البروجيكت ده؟

Coding Agent بيشتغل في الترمينال — بتكتبله طلب بالعربي أو الإنجليزي زي:

> *"اعمل Python script يقرأ ملف CSV ويرسم bar chart"*

وهو بيفكر، يكتب الكود، ويشغّله — لكن **بيوقف قبل أي تغيير ويسألك موافقة** مع عرض الـ diff بألوان.

---

## هيكل البروجيكت

```
coding_agent/
├── agent.py                ← شغّل ده
├── config.py               ← كل الإعدادات هنا
├── setup.sh                ← إعداد البيئة من الصفر
├── workspace/              ← ملفاتك بتتنشأ هنا (مشترك مع Docker)
│
├── agent/
│   ├── state.py            ← AgentState و FileDiff و CommandAction
│   ├── tools.py            ← read, list, edit, diff ملوّن
│   ├── graph.py            ← يربط الـ nodes ببعض
│   └── nodes/
│       ├── planner.py      ← يفهم الطلب ويعمل خطة
│       ├── researcher.py   ← يقرأ ملفاتك الموجودة
│       ├── writer.py       ← يكتب JSON list من الأوامر
│       ├── approval.py     ← ⏸ بتوافق هنا قبل أي تغيير
│       ├── executor.py     ← ينفّذ اللي وافقت عليه
│       ├── critic.py       ← يقيّم النتيجة (SUCCESS/RETRY)
│       └── finalizer.py    ← ملخص نهائي
│
├── llm/
│   └── client.py           ← vLLM client (OpenAI-compatible)
│
└── sandbox/
    └── docker_runner.py    ← كل run_command بيشتغل هنا (معزول)
```

---

## التدفق خطوة بخطوة

```
أنت تكتب طلب
      ↓
  Planner        → يعمل خطة مرقمة
      ↓
  Researcher     → يقرأ ملفاتك الموجودة
      ↓
  Writer         → يكتب JSON list من الأوامر
      ↓
  ⏸ Approval    → بتشوف الـ diff وتوافق [y/n/e/a]
      ↓
  Executor       → ينفّذ اللي وافقت عليه
      ↓
  Critic         → SUCCESS أو RETRY؟
   ↙    ↘
Writer  Finalizer → ملخص نهائي
(retry)
```

---

## الإعداد والتشغيل

### 1. تثبيت المتطلبات

```bash
bash setup.sh
```

أو يدوياً:
```bash
pip install langgraph langchain langchain-openai langsmith
docker pull python:3.11-slim
```

### 2. تشغيل vLLM

```bash
python -m vllm.entrypoints.openai.api_server \
  --model Qwen/Qwen2.5-Coder-7B-Instruct \
  --port 8000
```

> أو أي model تاني — غيّر `VLLM_MODEL` في `config.py`

### 3. تشغيل الـ Agent

```bash
python agent.py
```

---

## خيارات الموافقة (Approval Gate)

لما الـ Agent يقترح تغيير بتشوف:

```
╔══════════════════════════════════════════╗
║  [1/2] إنشاء جديد ✨  →  workspace/plot.py
║  ─────────────────────────────────────────
║  + import pandas as pd
║  + import matplotlib.pyplot as plt
║  + ...
╚══════════════════════════════════════════╝

  [y] وافق   [n] ارفض   [e] عدّل   [a] وافق الكل
```

| خيار | المعنى |
|------|--------|
| `y`  | وافق على التغيير ده |
| `n`  | ارفض (مش هيتنفذ) |
| `e`  | افتح editor تعدّل فيه الكود |
| `a`  | وافق على كل التغييرات الباقية |

---

## الإعدادات (config.py)

```python
# vLLM
VLLM_BASE_URL  = "http://localhost:8000/v1"
VLLM_MODEL     = "qwen2.5-coder:7b"

# Docker
DOCKER_ENABLED   = True          # False = شغّل محلياً (للتجربة)
WORKSPACE_DIR    = "/path/to/workspace"

# Agent
MAX_RETRIES      = 5             # أقصى عدد مرات الـ retry
```

---

## أمثلة على الاستخدام

```
❯ اعمل Python script يقرأ CSV ويرسم bar chart واحفظ النتيجة كـ PNG

❯ create a FastAPI app with /health and /predict endpoints

❯ اعمل مجلد utils فيه ملف helpers.py بفنكشنات للتعامل مع dates

❯ fix the bug in app.py — the function calculate_total returns wrong value

❯ اكتب unit tests لكل الفنكشنات في utils/helpers.py
```

---

## ملاحظات مهمة

- **الملفات بتتنشأ في `workspace/`** — مش على جهازك مباشرة
- **الأوامر بتشتغل جوا Docker** — معزولة تماماً عن نظامك
- **vLLM لازم يكون شغّال** قبل ما تشغّل الـ agent
- **بدون موافقتك** مش هيتعدّل أي ملف أو يتنفّذ أي أمر

---

## المتطلبات

- Python 3.10+
- Docker
- vLLM server شغّال
- `pip install langgraph langchain langchain-openai`
