# ============================================================
#  config.py — كل إعدادات البروجيكت هنا
# ============================================================

# --- vLLM server ---
VLLM_BASE_URL   = "http://localhost:8000/v1"
VLLM_API_KEY    = "dummy"          # vLLM مش محتاج key حقيقي
VLLM_MODEL      = "qwen2.5-coder:7b"
LLM_TEMPERATURE = 0.2

# --- Agent behaviour ---
MAX_RETRIES = 5                    # أقصى عدد مرات إعادة المحاولة
RECURSION_LIMIT = 60               # LangGraph recursion limit

# --- Docker sandbox ---
DOCKER_ENABLED    = True           # False = شغّل الأوامر على جهازك مباشرة (للتجربة فقط)
DOCKER_IMAGE      = "python:3.11-slim"
DOCKER_CONTAINER  = "coding_agent_sandbox"
WORKSPACE_DIR     = "/home/claude/coding_agent/workspace"   # المجلد المشترك مع الـ container

# --- LangSmith tracing (اختياري) ---
LANGSMITH_ENABLED = False
LANGSMITH_PROJECT = "coding_agent"
# LANGSMITH_API_KEY = "..."         # uncommment وحط الـ key لو عايز tracing

# --- Terminal colors ---
class C:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    DIM    = "\033[2m"
    ADD    = "\033[42m\033[30m"    # خلفية خضرا للسطور المضافة في الـ diff
    DEL    = "\033[41m\033[97m"    # خلفية حمرا للسطور المحذوفة في الـ diff
