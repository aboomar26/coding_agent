# ============================================================
#  sandbox/docker_runner.py — تنفيذ الأوامر داخل Docker
# ============================================================

import subprocess
import shlex
from config import (
    DOCKER_ENABLED, DOCKER_IMAGE, DOCKER_CONTAINER,
    WORKSPACE_DIR, C
)


def ensure_container() -> bool:
    """
    يتأكد إن الـ container شغّال.
    لو مش موجود يعمله ويشغّله.
    يرجع True لو تمام.
    """
    # تحقق لو الـ container شغّال
    check = subprocess.run(
        ["docker", "inspect", "-f", "{{.State.Running}}", DOCKER_CONTAINER],
        capture_output=True, text=True
    )
    if check.returncode == 0 and check.stdout.strip() == "true":
        return True

    print(f"{C.CYAN}[SANDBOX]{C.RESET} بيشغّل الـ Docker container...")

    # وقّف أي container قديم بنفس الاسم
    subprocess.run(
        ["docker", "rm", "-f", DOCKER_CONTAINER],
        capture_output=True
    )

    # شغّل container جديد مع mount للـ workspace
    result = subprocess.run([
        "docker", "run", "-d",
        "--name",   DOCKER_CONTAINER,
        "--rm",                              # بيتحذف لما يوقف
        "-v", f"{WORKSPACE_DIR}:/workspace", # mount الـ workspace
        "-w", "/workspace",
        DOCKER_IMAGE,
        "tail", "-f", "/dev/null"            # يفضل شغّال
    ], capture_output=True, text=True)

    if result.returncode != 0:
        print(f"{C.RED}[SANDBOX ERROR]{C.RESET} {result.stderr.strip()}")
        return False

    # ثبّت الـ dependencies الأساسية
    subprocess.run(
        ["docker", "exec", DOCKER_CONTAINER,
         "pip", "install", "--quiet", "pandas", "matplotlib", "requests"],
        capture_output=True
    )

    print(f"{C.GREEN}[SANDBOX]{C.RESET} Container جاهز ✓")
    return True


def run_in_sandbox(command: str, working_dir: str = "/workspace") -> tuple[str, int]:
    """
    شغّل أمر shell جوا الـ Docker container.

    - الـ working_dir بيتحول من /workspace المحلي للـ /workspace داخل الـ container
    - الـ output بيتقلص لو أكبر من 2000 حرف
    """
    if not DOCKER_ENABLED:
        return _run_local(command, working_dir)

    if not ensure_container():
        return "Error: مش قادر يشغّل الـ Docker container", 1

    # حوّل الـ path المحلي لـ path داخل الـ container
    container_dir = working_dir.replace(WORKSPACE_DIR, "/workspace") \
                               .replace("\\", "/") or "/workspace"

    docker_cmd = [
        "docker", "exec",
        "-w", container_dir,
        DOCKER_CONTAINER,
        "bash", "-c", command
    ]

    try:
        process = subprocess.Popen(
            docker_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        output, _ = process.communicate(timeout=60)
        code = process.returncode

        # قلّص لو كبير
        if len(output) > 2000:
            output = output[:1000] + "\n\n[...مقطوع...]\n\n" + output[-1000:]

        return output, code

    except subprocess.TimeoutExpired:
        process.kill()
        return "Error: الأمر استغرق أكتر من 60 ثانية", 1
    except Exception as e:
        return f"Error: {e}", 1


def _run_local(command: str, working_dir: str = ".") -> tuple[str, int]:
    """fallback: شغّل الأمر محلياً (لو DOCKER_ENABLED=False)"""
    try:
        process = subprocess.Popen(
            command, shell=True,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, cwd=working_dir
        )
        output, _ = process.communicate(timeout=60)
        code = process.returncode
        if len(output) > 2000:
            output = output[:1000] + "\n\n[...مقطوع...]\n\n" + output[-1000:]
        return output, code
    except subprocess.TimeoutExpired:
        process.kill()
        return "Error: timeout", 1
    except Exception as e:
        return str(e), 1


def stop_container():
    """وقّف الـ container لما البروجيكت يخلص"""
    if DOCKER_ENABLED:
        subprocess.run(["docker", "stop", DOCKER_CONTAINER], capture_output=True)
        print(f"{C.DIM}[SANDBOX] Container وقف.{C.RESET}")
