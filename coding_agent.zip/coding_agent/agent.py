#!/usr/bin/env python3
# ============================================================
#  agent.py — نقطة الدخول الرئيسية
#  شغّل: python agent.py
# ============================================================

import sys
import os

# أضف الـ root للـ path
sys.path.insert(0, os.path.dirname(__file__))

from langchain_core.messages import HumanMessage
from agent.graph import build_graph
from agent.state import AgentState
from sandbox.docker_runner import ensure_container, stop_container
from config import C, WORKSPACE_DIR, DOCKER_ENABLED, RECURSION_LIMIT


BANNER = f"""
{C.BOLD}{C.CYAN}
  ╔══════════════════════════════════════════╗
  ║        🤖  Coding Agent  v2.0            ║
  ║   LangGraph + vLLM + Docker Sandbox      ║
  ╚══════════════════════════════════════════╝
{C.RESET}
  {C.DIM}Workspace : {WORKSPACE_DIR}
  Docker    : {'✓ مفعّل' if DOCKER_ENABLED else '✗ معطّل (local mode)'}
  اكتب طلبك وادغط Enter | اكتب 'exit' للخروج{C.RESET}
"""


def run_agent(user_request: str) -> str:
    """شغّل الـ pipeline على طلب واحد"""

    initial_state: AgentState = {
        "messages"        : [HumanMessage(content=user_request)],
        "user_request"    : user_request,
        "plan"            : "",
        "context"         : "",
        "raw_actions"     : "[]",
        "file_diffs"      : [],
        "command_actions" : [],
        "last_tool_result": "",
        "status"          : "running",
        "retry_count"     : 0,
        "critic_note"     : "",
        "final_answer"    : "",
    }

    graph = build_graph()

    final_state = None
    try:
        for chunk in graph.stream(
            initial_state,
            {"recursion_limit": RECURSION_LIMIT}
        ):
            final_state = chunk
    except KeyboardInterrupt:
        print(f"\n\n{C.YELLOW}⚠ تم إيقاف العملية من المستخدم{C.RESET}")
        return "تم الإيقاف"

    if final_state:
        last_node_output = list(final_state.values())[-1]
        return last_node_output.get("final_answer", "تمت المهمة")

    return "لم يتم إنتاج أي مخرجات"


def main():
    print(BANNER)

    # تأكد إن الـ workspace موجود
    os.makedirs(WORKSPACE_DIR, exist_ok=True)

    # جهّز الـ Docker container
    if DOCKER_ENABLED:
        ensure_container()

    try:
        while True:
            print(f"\n{C.BOLD}{'─'*60}{C.RESET}")
            try:
                user_input = input(f"  {C.GREEN}❯{C.RESET} ").strip()
            except (EOFError, KeyboardInterrupt):
                break

            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "خروج"):
                break

            run_agent(user_input)

    finally:
        if DOCKER_ENABLED:
            stop_container()
        print(f"\n{C.DIM}وداعاً! 👋{C.RESET}\n")


if __name__ == "__main__":
    main()
