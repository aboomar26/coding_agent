# ============================================================
#  agent/nodes/approval.py — ⏸ Human-in-the-loop gate
# ============================================================

import os
import tempfile
import subprocess
from agent.state import AgentState, FileDiff, CommandAction
from agent.tools import _read_file, print_colored_diff
from config import C, WORKSPACE_DIR


# ────────────────────────────────────────────────
# Helper: اسأل المستخدم
# ────────────────────────────────────────────────

def _ask(prompt: str) -> str:
    """اقرأ إجابة المستخدم مع handling للـ EOF"""
    try:
        return input(prompt).strip().lower()
    except EOFError:
        return "n"


def _open_editor(initial_text: str) -> str:
    """افتح editor للمستخدم يعدّل فيه النص"""
    editor = os.environ.get("EDITOR", "nano")
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".py", delete=False, encoding="utf-8"
    ) as f:
        f.write(initial_text)
        tmp_path = f.name
    subprocess.run([editor, tmp_path])
    with open(tmp_path, "r", encoding="utf-8") as f:
        result = f.read()
    os.unlink(tmp_path)
    return result


# ────────────────────────────────────────────────
# موافقة على تعديلات الملفات
# ────────────────────────────────────────────────

def _review_file_diffs(diffs: list[FileDiff]) -> list[FileDiff]:
    if not diffs:
        return diffs

    print(f"\n{C.BOLD}{C.BLUE}{'─'*60}{C.RESET}")
    print(f"{C.BOLD}  📝  تغييرات الملفات  ({len(diffs)} ملف){C.RESET}")
    print(f"{C.BOLD}{'─'*60}{C.RESET}")

    approved: list[FileDiff] = []
    approve_all = False

    for i, diff in enumerate(diffs):
        filename    = diff["filename"]
        find_str    = diff["find_str"]
        replace_str = diff["replace_str"]

        # اقرأ المحتوى الحالي
        old_content = _read_file(filename) if os.path.exists(
            filename if os.path.isabs(filename) else os.path.join(WORKSPACE_DIR, filename)
        ) else ""

        action_label = "إنشاء جديد ✨" if not find_str else "تعديل 📝"
        print(f"\n  [{i+1}/{len(diffs)}] {C.BOLD}{action_label}{C.RESET}  →  {C.CYAN}{filename}{C.RESET}")

        # اعرض الـ diff
        print_colored_diff(filename, old_content, replace_str if not find_str else old_content.replace(find_str, replace_str))

        if approve_all:
            print(f"  {C.GREEN}✓ تمت الموافقة تلقائياً{C.RESET}")
            approved.append({**diff, "approved": True})
            continue

        choice = _ask(
            f"\n  {C.BOLD}[y]{C.RESET}وافق  "
            f"{C.BOLD}[n]{C.RESET}ارفض  "
            f"{C.BOLD}[e]{C.RESET}عدّل  "
            f"{C.BOLD}[a]{C.RESET}وافق الكل  : "
        )

        if choice in ("y", ""):
            approved.append({**diff, "approved": True})
            print(f"  {C.GREEN}✓ تمت الموافقة{C.RESET}")
        elif choice == "a":
            approve_all = True
            approved.append({**diff, "approved": True})
            print(f"  {C.GREEN}✓ تمت الموافقة على الكل{C.RESET}")
        elif choice == "e":
            new_text = _open_editor(replace_str)
            approved.append({**diff, "replace_str": new_text, "approved": True})
            print(f"  {C.GREEN}✓ تمت الموافقة بعد التعديل{C.RESET}")
        else:
            print(f"  {C.RED}✗ تم الرفض{C.RESET}")
            approved.append({**diff, "approved": False})

    return approved


# ────────────────────────────────────────────────
# موافقة على الأوامر
# ────────────────────────────────────────────────

def _review_commands(commands: list[CommandAction]) -> list[CommandAction]:
    if not commands:
        return commands

    print(f"\n{C.BOLD}{C.YELLOW}{'─'*60}{C.RESET}")
    print(f"{C.BOLD}  ⚡  أوامر التنفيذ  ({len(commands)} أمر){C.RESET}")
    print(f"{C.BOLD}{'─'*60}{C.RESET}")

    approved: list[CommandAction] = []
    approve_all = False

    for i, cmd in enumerate(commands):
        command     = cmd["command"]
        working_dir = cmd["working_dir"]

        print(f"\n  [{i+1}/{len(commands)}]")
        print(f"  {C.BOLD}الأمر    :{C.RESET} {C.YELLOW}{command}{C.RESET}")
        print(f"  {C.BOLD}المجلد   :{C.RESET} {C.DIM}{working_dir}{C.RESET}")

        if approve_all:
            print(f"  {C.GREEN}✓ تمت الموافقة تلقائياً{C.RESET}")
            approved.append({**cmd, "approved": True})
            continue

        choice = _ask(
            f"\n  {C.BOLD}[y]{C.RESET}نفّذ  "
            f"{C.BOLD}[n]{C.RESET}تخطى  "
            f"{C.BOLD}[a]{C.RESET}وافق الكل  : "
        )

        if choice in ("y", ""):
            approved.append({**cmd, "approved": True})
            print(f"  {C.GREEN}✓ سيتم التنفيذ{C.RESET}")
        elif choice == "a":
            approve_all = True
            approved.append({**cmd, "approved": True})
            print(f"  {C.GREEN}✓ تمت الموافقة على الكل{C.RESET}")
        else:
            approved.append({**cmd, "approved": False})
            print(f"  {C.YELLOW}⚠ تم التخطي{C.RESET}")

    return approved


# ────────────────────────────────────────────────
# الـ Node الرئيسي
# ────────────────────────────────────────────────

def node_approval(state: AgentState) -> AgentState:
    """
    ⏸ يوقف التنفيذ ويعرض كل التغييرات للمستخدم قبل ما تتنفذ.

    - لكل ملف: بيعرض diff ملوّن + خيارات [y/n/e/a]
    - لكل أمر: بيعرض الأمر والمجلد + خيارات [y/n/a]
    """
    print(f"\n{C.BOLD}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  ⏸   APPROVAL GATE{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")
    print(f"\n  {C.DIM}راجع التغييرات المقترحة ووافق أو ارفض كل واحدة{C.RESET}")

    file_diffs      = state.get("file_diffs", [])
    command_actions = state.get("command_actions", [])

    if not file_diffs and not command_actions:
        print(f"  {C.DIM}لا يوجد تغييرات للمراجعة{C.RESET}")
        return state

    reviewed_diffs    = _review_file_diffs(file_diffs)
    reviewed_commands = _review_commands(command_actions)

    print(f"\n{C.BOLD}{'─'*60}{C.RESET}")
    approved_f = sum(1 for d in reviewed_diffs    if d["approved"])
    approved_c = sum(1 for c in reviewed_commands if c["approved"])
    print(f"  ملخص: {C.GREEN}{approved_f}/{len(reviewed_diffs)}{C.RESET} ملف | "
          f"{C.GREEN}{approved_c}/{len(reviewed_commands)}{C.RESET} أمر — تمت الموافقة")

    return {
        **state,
        "file_diffs"      : reviewed_diffs,
        "command_actions" : reviewed_commands,
    }
