# ============================================================
#  agent/nodes/critic.py — يقيّم النتيجة ويقرر: SUCCESS أو RETRY
# ============================================================

from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from agent.state import AgentState
from llm.client import get_llm
from config import C, MAX_RETRIES


def node_critic(state: AgentState) -> AgentState:
    """
    يراجع نتيجة الـ Executor ويقرر:
    - SUCCESS: كل حاجة تمت صح → يكمل للـ Finalizer
    - RETRY:   في مشكلة → يرجع للـ Writer (لحد MAX_RETRIES مرة)
    """
    print(f"\n{C.BOLD}{C.RED}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  🔎  CRITIC{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    retry_count = state.get("retry_count", 0)

    # لو وصلنا للحد الأقصى → أجبر SUCCESS
    if retry_count >= MAX_RETRIES:
        note = f"وصلنا للحد الأقصى ({MAX_RETRIES} مرات) — اعتبرنا النتيجة مقبولة"
        print(f"  {C.YELLOW}⚠ {note}{C.RESET}")
        return {**state, "status": "success", "critic_note": note}

    llm = get_llm(temperature=0)

    system = SystemMessage(content=(
        "You are a strict Critic agent. Evaluate whether the execution results indicate SUCCESS or FAILURE.\n\n"
        "SUCCESS if:\n"
        "  - All commands had exit_code=0\n"
        "  - Files were created or modified successfully (messages starting with ✓)\n"
        "  - No Error messages\n"
        "  - User cancelled some actions (that's OK — still SUCCESS)\n\n"
        "RETRY if:\n"
        "  - Any exit_code != 0\n"
        "  - Any line starting with 'Error:'\n"
        "  - JSON parsing failed\n"
        "  - The plan was clearly not implemented\n\n"
        "Respond with EXACTLY:\n"
        "Line 1: SUCCESS  or  RETRY\n"
        "Line 2: One sentence explaining why"
    ))
    human = HumanMessage(content=(
        f"Original plan:\n{state['plan']}\n\n"
        f"Execution results:\n{state['last_tool_result']}"
    ))

    response = llm.invoke([system, human])
    verdict  = response.content.strip() if isinstance(response.content, str) else ""

    lines      = verdict.split("\n", 1)
    first_word = lines[0].strip().upper()
    note       = lines[1].strip() if len(lines) > 1 else verdict
    status     = "success" if first_word == "SUCCESS" else "retry"

    icon   = f"{C.GREEN}✓ SUCCESS{C.RESET}" if status == "success" \
             else f"{C.RED}↺ RETRY ({retry_count+1}/{MAX_RETRIES}){C.RESET}"
    print(f"\n  {icon}")
    print(f"  {C.DIM}{note}{C.RESET}")

    return {
        **state,
        "status"     : status,
        "critic_note": note,
        "retry_count": retry_count + (1 if status == "retry" else 0),
        "messages"   : state["messages"] + [
            AIMessage(content=f"[CRITIC] {verdict}"),
        ],
    }
