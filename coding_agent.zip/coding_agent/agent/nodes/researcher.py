# ============================================================
#  agent/nodes/researcher.py
# ============================================================

from langchain_core.messages import (
    SystemMessage, HumanMessage, AIMessage, ToolMessage, BaseMessage
)
from agent.state import AgentState
from agent.tools import read_file_content, list_directory, _list_dir
from llm.client import get_llm
from config import C, WORKSPACE_DIR


def node_researcher(state: AgentState) -> AgentState:
    """
    يستكشف ملفات الـ workspace ويبني context summary للـ Writer.
    يستخدم فقط read_file و list_directory — مش بيعدل حاجة.
    """
    print(f"\n{C.BOLD}{C.GREEN}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  🔍  RESEARCHER{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    llm    = get_llm()
    tools  = [list_directory, read_file_content]
    llm_r  = llm.bind_tools(tools)

    # ابدأ بعرض محتويات الـ workspace تلقائياً
    workspace_content = _list_dir(WORKSPACE_DIR)

    system = SystemMessage(content=(
        "You are a Researcher agent. Your goal: gather all context before writing code.\n"
        "Available tools: list_directory, read_file_content\n"
        "Rules:\n"
        "- Read existing files that are relevant to the plan\n"
        "- Note the current project structure\n"
        "- Do NOT modify any files\n"
        "- After gathering info, write a concise CONTEXT SUMMARY\n"
        "- If workspace is empty, just say 'Empty workspace — will create files from scratch'"
    ))
    human = HumanMessage(content=(
        f"Plan to execute:\n{state['plan']}\n\n"
        f"Current workspace contents:\n{workspace_content}\n\n"
        "Explore relevant files then write your context summary."
    ))

    messages: list[BaseMessage] = [system, human]
    context_summary = ""

    for _ in range(8):
        response = llm_r.invoke(messages)
        messages.append(response)

        tool_calls = getattr(response, "tool_calls", [])
        if not tool_calls:
            content = response.content
            context_summary = content if isinstance(content, str) else str(content)
            break

        for tc in tool_calls:
            name = tc["name"]
            args = tc["args"]
            if name == "list_directory":
                result = _list_dir(args.get("path", "."))
            elif name == "read_file_content":
                from agent.tools import _read_file
                result = _read_file(args.get("path", ""))
            else:
                result = f"Tool {name} غير متاح في الـ Researcher"

            messages.append(ToolMessage(content=result, tool_call_id=tc["id"]))

    print(f"\n{C.CYAN}Context Summary:{C.RESET}\n{context_summary}\n")

    return {
        **state,
        "context" : context_summary,
        "messages": state["messages"] + [
            AIMessage(content=f"[CONTEXT]\n{context_summary}"),
        ],
    }
