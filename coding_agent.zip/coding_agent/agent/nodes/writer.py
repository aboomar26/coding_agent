# ============================================================
#  agent/nodes/writer.py
# ============================================================

import json
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from agent.state import AgentState, FileDiff, CommandAction
from llm.client import get_llm
from config import C, WORKSPACE_DIR


def node_writer(state: AgentState) -> AgentState:
    """
    يولّد قائمة JSON من الأوامر المطلوبة.
    الـ output بيتحوّل لـ FileDiff و CommandAction objects.
    """
    print(f"\n{C.BOLD}{C.YELLOW}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  ✍️   WRITER{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    llm = get_llm()

    retry_note = ""
    if state.get("retry_count", 0) > 0:
        retry_note = (
            f"\n\n⚠️  RETRY #{state['retry_count']}\n"
            f"Previous attempt failed:\n{state.get('critic_note', '')}\n"
            f"Tool results:\n{state.get('last_tool_result', '')}\n"
            "Please fix the issue and try a different approach."
        )

    system = SystemMessage(content=(
        "You are a Writer agent. Output ONLY a JSON array of actions.\n\n"
        "Each action is one of:\n"
        '  {"tool": "edit_file",        "args": {"filename": "...", "find_str": "...", "replace_str": "..."}}\n'
        '  {"tool": "run_command",       "args": {"command": "...", "working_dir": "/workspace"}}\n'
        '  {"tool": "read_file_content", "args": {"path": "..."}}\n'
        '  {"tool": "list_directory",    "args": {"path": "..."}}\n\n'
        "Rules for edit_file:\n"
        '  - To CREATE a new file: find_str must be "" (empty string)\n'
        '  - To MODIFY a file: find_str must be the EXACT text to replace\n'
        f"  - Always use absolute paths starting with {WORKSPACE_DIR}\n"
        "  - Write complete, working code — not placeholders\n\n"
        "Rules for run_command:\n"
        f'  - working_dir should be "{WORKSPACE_DIR}" or a subdirectory\n'
        "  - One command per action object\n\n"
        "CRITICAL: Return ONLY the raw JSON array. No markdown fences, no explanation."
    ))

    human = HumanMessage(content=(
        f"Plan:\n{state['plan']}\n\n"
        f"Context:\n{state['context']}\n"
        f"{retry_note}\n\n"
        "Output the JSON action list now:"
    ))

    response = llm.invoke([system, human])
    raw = response.content if isinstance(response.content, str) else str(response.content)
    raw = raw.strip()

    # نظّف الـ markdown fences لو موجودة
    if raw.startswith("```"):
        parts = raw.split("```")
        raw = parts[1] if len(parts) > 1 else raw
        if raw.startswith("json"):
            raw = raw[4:]
    raw = raw.strip().strip("`").strip()

    print(f"\n{C.CYAN}Actions JSON:{C.RESET}\n{raw}\n")

    # حوّل الـ JSON لـ typed objects
    file_diffs: list[FileDiff]          = []
    command_actions: list[CommandAction] = []

    try:
        actions = json.loads(raw)
        for action in actions:
            tool = action.get("tool", "")
            args = action.get("args", {})
            if tool == "edit_file":
                file_diffs.append(FileDiff(
                    filename    = args.get("filename", ""),
                    find_str    = args.get("find_str", ""),
                    replace_str = args.get("replace_str", ""),
                    approved    = False
                ))
            elif tool == "run_command":
                command_actions.append(CommandAction(
                    command     = args.get("command", ""),
                    working_dir = args.get("working_dir", WORKSPACE_DIR),
                    approved    = False
                ))
    except json.JSONDecodeError:
        print(f"{C.RED}[WRITER] JSON parsing فشل — هيتعامل معاه الـ Executor{C.RESET}")

    return {
        **state,
        "raw_actions"     : raw,
        "file_diffs"      : file_diffs,
        "command_actions" : command_actions,
        "messages"        : state["messages"] + [
            AIMessage(content=f"[WRITER]\n{raw}"),
        ],
    }
