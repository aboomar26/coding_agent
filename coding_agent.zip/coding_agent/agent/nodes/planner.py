# ============================================================
#  agent/nodes/planner.py
# ============================================================

from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from agent.state import AgentState
from llm.client import get_llm
from config import C


def node_planner(state: AgentState) -> AgentState:
    """
    يقرأ طلب المستخدم ويولّد خطة مرقمة واضحة.
    مش بيكتب كود — بس بيفكر.
    """
    print(f"\n{C.BOLD}{C.PURPLE if hasattr(C,'PURPLE') else C.BLUE}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  📋  PLANNER{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    llm = get_llm()

    system = SystemMessage(content=(
        "You are a senior software engineer acting as a Planner.\n"
        "Your ONLY job: read the user's request and output a clear numbered plan.\n"
        "Rules:\n"
        "- Be specific about filenames and folder structure\n"
        "- Mention which files to create and which to modify\n"
        "- Do NOT write any code yet\n"
        "- Do NOT call any tools\n"
        "- Output ONLY the numbered plan, nothing else"
    ))
    human = HumanMessage(content=(
        f"Workspace directory: {state.get('workspace', 'workspace/')}\n\n"
        f"User request:\n{state['user_request']}\n\n"
        "Write the step-by-step plan."
    ))

    response = llm.invoke([system, human])
    plan = response.content if isinstance(response.content, str) else str(response.content)

    print(f"\n{C.CYAN}الخطة:{C.RESET}\n{plan}\n")

    return {
        **state,
        "plan"    : plan,
        "status"  : "running",
        "messages": state["messages"] + [
            human,
            AIMessage(content=f"[PLAN]\n{plan}"),
        ],
    }
