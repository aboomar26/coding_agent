# ============================================================
#  agent/nodes/finalizer.py — ملخص النهاية
# ============================================================

from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
from agent.state import AgentState
from llm.client import get_llm
from config import C


def node_finalizer(state: AgentState) -> AgentState:
    """
    يكتب ملخص نهائي واضح للمستخدم:
    - إيه اللي اتعمل
    - أنهي ملفات اتنشأت / اتعدلت
    - أنهي أوامر اشتغلت
    - أي خطوات جاية
    """
    print(f"\n{C.BOLD}{C.GREEN}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  ✅  FINALIZER{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    llm = get_llm()

    # اجمع ملخص الملفات المتأثرة
    file_diffs      = state.get("file_diffs", [])
    command_actions = state.get("command_actions", [])

    files_summary = "\n".join(
        f"  - {'إنشاء' if not d['find_str'] else 'تعديل'}: {d['filename']} "
        f"({'✓ مُنفّذ' if d['approved'] else '✗ مرفوض'})"
        for d in file_diffs
    ) or "  لا يوجد"

    cmds_summary = "\n".join(
        f"  - {c['command']} "
        f"({'✓ نُفّذ' if c['approved'] else '✗ متخطى'})"
        for c in command_actions
    ) or "  لا يوجد"

    system = SystemMessage(content=(
        "You are a Finalizer agent. Write a clear, friendly summary for the user.\n"
        "Structure:\n"
        "1. What was accomplished\n"
        "2. Files created/modified\n"
        "3. Commands run\n"
        "4. How to run / test the result\n"
        "5. Any suggestions for next steps\n"
        "Be concise and practical. Use Arabic if the user wrote in Arabic."
    ))
    human = HumanMessage(content=(
        f"User request:\n{state['user_request']}\n\n"
        f"Plan:\n{state['plan']}\n\n"
        f"Files affected:\n{files_summary}\n\n"
        f"Commands run:\n{cmds_summary}\n\n"
        f"Execution results:\n{state.get('last_tool_result', '')}\n\n"
        "Write the final summary."
    ))

    response = llm.invoke([system, human])
    summary  = response.content if isinstance(response.content, str) else str(response.content)

    # ── اطبع الملخص بشكل جميل ──
    print(f"\n{'═'*60}")
    print(f"{C.BOLD}{C.GREEN}  ✅  تم بنجاح!{C.RESET}")
    print(f"{'═'*60}")
    print(f"\n{summary}")
    print(f"\n{'═'*60}\n")

    return {
        **state,
        "final_answer": summary,
        "messages"    : state["messages"] + [AIMessage(content=summary)],
    }
