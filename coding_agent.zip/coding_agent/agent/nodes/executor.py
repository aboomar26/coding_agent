# ============================================================
#  agent/nodes/executor.py — ينفّذ الأوامر المعتمدة
# ============================================================

import json
from langchain_core.messages import AIMessage
from agent.state import AgentState
from agent.tools import _edit_file, _read_file, _list_dir
from sandbox.docker_runner import run_in_sandbox
from config import C


def node_executor(state: AgentState) -> AgentState:
    """
    ينفّذ الأوامر اللي وافق عليها المستخدم في الـ Approval Gate.
    - edit_file → بيكتب على الملف مباشرة في الـ workspace
    - run_command → بيشغّل جوا الـ Docker container
    """
    print(f"\n{C.BOLD}{C.CYAN}{'═'*60}{C.RESET}")
    print(f"{C.BOLD}  ⚙️   EXECUTOR{C.RESET}")
    print(f"{C.BOLD}{'═'*60}{C.RESET}")

    results: list[str] = []

    # ── تنفيذ تعديلات الملفات ─────────────────────────────
    file_diffs = state.get("file_diffs", [])
    for diff in file_diffs:
        if not diff.get("approved"):
            results.append(f"⏭ تم تخطي: {diff['filename']}")
            continue

        msg, old, new = _edit_file(
            diff["filename"],
            diff["find_str"],
            diff["replace_str"]
        )
        print(f"  {C.GREEN if msg.startswith('✓') else C.RED}{msg}{C.RESET}")
        results.append(msg)

    # ── تنفيذ الأوامر في Docker ───────────────────────────
    command_actions = state.get("command_actions", [])
    for cmd in command_actions:
        if not cmd.get("approved"):
            results.append(f"⏭ تم تخطي الأمر: {cmd['command']}")
            continue

        command     = cmd["command"]
        working_dir = cmd["working_dir"]

        print(f"\n  {C.YELLOW}▶ {command}{C.RESET}")
        print(f"  {C.DIM}في: {working_dir}{C.RESET}")

        output, code = run_in_sandbox(command, working_dir)

        status = f"{C.GREEN}exit_code=0 ✓{C.RESET}" if code == 0 \
                 else f"{C.RED}exit_code={code} ✗{C.RESET}"
        print(f"  {status}")

        if output.strip():
            # اطبع أول 20 سطر من الـ output
            lines = output.strip().split("\n")
            preview = "\n".join(f"  {C.DIM}│{C.RESET} {l}" for l in lines[:20])
            print(preview)
            if len(lines) > 20:
                print(f"  {C.DIM}│ ... ({len(lines)-20} سطر تانية){C.RESET}")

        results.append(
            f"run_command({command!r}): {output.strip()}\n[exit_code={code}]"
        )

    # ── fallback: لو الـ Writer بعت JSON مباشرة ولم يُعالَج ─
    if not file_diffs and not command_actions:
        raw = state.get("raw_actions", "[]")
        try:
            actions = json.loads(raw)
            for action in actions:
                tool = action.get("tool", "")
                args = action.get("args", {})
                if tool == "read_file_content":
                    r = _read_file(args.get("path", ""))
                    results.append(f"read_file_content: {r[:500]}")
                elif tool == "list_directory":
                    r = _list_dir(args.get("path", "."))
                    results.append(f"list_directory: {r}")
        except Exception:
            results.append("لا يوجد actions للتنفيذ")

    combined = "\n\n".join(results) if results else "لم يتم تنفيذ أي شيء"

    print(f"\n{C.DIM}{'─'*60}{C.RESET}")
    print(f"  {C.DIM}نتيجة التنفيذ: {len(results)} عملية{C.RESET}")

    return {
        **state,
        "last_tool_result": combined,
        "messages"        : state["messages"] + [
            AIMessage(content=f"[EXECUTOR]\n{combined}"),
        ],
    }
