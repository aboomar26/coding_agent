# ============================================================
#  agent/tools.py — الـ tools الأساسية (read, list, edit, run)
# ============================================================

import os
import difflib
from langchain_core.tools import tool
from config import WORKSPACE_DIR, C
from sandbox.docker_runner import run_in_sandbox


# ────────────────────────────────────────────────
# Helper: عرض diff ملوّن في الترمينال
# ────────────────────────────────────────────────

def print_colored_diff(filename: str, old: str, new: str):
    """يطبع الفرق بين النص القديم والجديد بألوان واضحة"""
    old_lines = old.splitlines(keepends=True) if old else []
    new_lines = new.splitlines(keepends=True)

    diff = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"before/{filename}",
        tofile=f"after/{filename}",
        lineterm=""
    ))

    if not diff:
        print(f"  {C.DIM}(لا يوجد تغيير){C.RESET}")
        return

    print(f"\n  {C.DIM}{'─'*56}{C.RESET}")
    for line in diff:
        if line.startswith("+++") or line.startswith("---"):
            print(f"  {C.BOLD}{line}{C.RESET}")
        elif line.startswith("+"):
            print(f"  {C.ADD} + {C.RESET} {line[1:].rstrip()}")
        elif line.startswith("-"):
            print(f"  {C.DEL} - {C.RESET} {line[1:].rstrip()}")
        elif line.startswith("@@"):
            print(f"  {C.CYAN}{line}{C.RESET}")
        else:
            print(f"  {C.DIM}{line.rstrip()}{C.RESET}")
    print(f"  {C.DIM}{'─'*56}{C.RESET}")


# ────────────────────────────────────────────────
# الـ raw functions (بتستخدمها الـ nodes مباشرة)
# ────────────────────────────────────────────────

def _read_file(path: str) -> str:
    """اقرأ محتوى ملف (مع clip لو كبير)"""
    # لو مسار نسبي، اعمله absolute جوا الـ workspace
    if not os.path.isabs(path):
        path = os.path.join(WORKSPACE_DIR, path)
    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        if len(content) > 3000:
            content = content[:1500] + "\n\n[...مقطوع...]\n\n" + content[-1500:]
        return content
    except FileNotFoundError:
        return f"Error: الملف '{path}' مش موجود"
    except PermissionError:
        return f"Error: مش مسموح بقراءة '{path}'"
    except UnicodeDecodeError:
        return f"Error: الملف '{path}' binary ومش قابل للقراءة"
    except Exception as e:
        return f"Error: {e}"


def _list_dir(path: str = ".") -> str:
    """اعرض محتويات مجلد"""
    if not os.path.isabs(path):
        path = os.path.join(WORKSPACE_DIR, path)
    try:
        items = os.listdir(path)
        if not items:
            return f"المجلد '{path}' فاضي"
        lines = [f"محتويات '{path}':"]
        for item in sorted(items):
            full = os.path.join(path, item)
            tag  = "📁" if os.path.isdir(full) else "📄"
            lines.append(f"  {tag} {item}")
        return "\n".join(lines)
    except FileNotFoundError:
        return f"Error: المجلد '{path}' مش موجود"
    except Exception as e:
        return f"Error: {e}"


def _edit_file(filename: str, find_str: str, replace_str: str) -> tuple[str, str, str]:
    """
    عدّل أو أنشئ ملف.
    يرجع (result_message, old_content, new_content)
    """
    if not os.path.isabs(filename):
        filename = os.path.join(WORKSPACE_DIR, filename)

    # تأكد إن المجلد الأب موجود
    os.makedirs(os.path.dirname(filename), exist_ok=True)

    # إنشاء ملف جديد
    if not os.path.exists(filename) and find_str == "":
        with open(filename, "w", encoding="utf-8") as f:
            f.write(replace_str)
        return f"✓ تم إنشاء: {filename}", "", replace_str

    # تعديل ملف موجود
    try:
        with open(filename, "r", encoding="utf-8") as f:
            old = f.read()
    except FileNotFoundError:
        if find_str == "":
            with open(filename, "w", encoding="utf-8") as f:
                f.write(replace_str)
            return f"✓ تم إنشاء: {filename}", "", replace_str
        return f"Error: الملف '{filename}' مش موجود", "", ""

    if find_str and find_str not in old:
        return f"Error: النص المطلوب مش موجود في '{filename}'", old, old

    new = old.replace(find_str, replace_str) if find_str else replace_str
    with open(filename, "w", encoding="utf-8") as f:
        f.write(new)
    return f"✓ تم التعديل: {filename}", old, new


# ────────────────────────────────────────────────
# LangChain @tool — للـ Researcher
# ────────────────────────────────────────────────

@tool
def read_file_content(path: str) -> str:
    """اقرأ محتوى ملف نصي وارجع محتواه."""
    print(f"  {C.DIM}[read] {path}{C.RESET}")
    return _read_file(path)


@tool
def list_directory(path: str = ".") -> str:
    """اعرض قائمة الملفات والمجلدات في المسار المحدد."""
    print(f"  {C.DIM}[list] {path}{C.RESET}")
    return _list_dir(path)
