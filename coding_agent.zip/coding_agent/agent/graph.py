# ============================================================
#  agent/graph.py — يربط الـ nodes ببعض
# ============================================================

from typing import Literal
from langgraph.graph import StateGraph, START, END
from agent.state import AgentState
from agent.nodes.planner    import node_planner
from agent.nodes.researcher import node_researcher
from agent.nodes.writer     import node_writer
from agent.nodes.approval   import node_approval
from agent.nodes.executor   import node_executor
from agent.nodes.critic     import node_critic
from agent.nodes.finalizer  import node_finalizer
from config import RECURSION_LIMIT


def route_after_critic(
    state: AgentState,
) -> Literal["node_writer", "node_finalizer"]:
    """
    بعد الـ Critic:
    - SUCCESS → Finalizer
    - RETRY   → Writer (يكتب approach جديد)
    """
    if state.get("status") == "success":
        return "node_finalizer"
    return "node_writer"


def build_graph():
    """
    يبني ويكمبايل الـ LangGraph pipeline.

    التدفق:
        START
          → Planner
          → Researcher
          → Writer
          → Approval Gate  ← ⏸ هنا بتوافق
          → Executor
          → Critic
          ↙         ↘
       Writer      Finalizer
      (RETRY)     (SUCCESS)
          → END
    """
    g = StateGraph(AgentState)

    # ── تسجيل الـ nodes ──
    g.add_node("node_planner",    node_planner)
    g.add_node("node_researcher", node_researcher)
    g.add_node("node_writer",     node_writer)
    g.add_node("node_approval",   node_approval)
    g.add_node("node_executor",   node_executor)
    g.add_node("node_critic",     node_critic)
    g.add_node("node_finalizer",  node_finalizer)

    # ── الحواف الثابتة ──
    g.add_edge(START,              "node_planner")
    g.add_edge("node_planner",     "node_researcher")
    g.add_edge("node_researcher",  "node_writer")
    g.add_edge("node_writer",      "node_approval")
    g.add_edge("node_approval",    "node_executor")
    g.add_edge("node_executor",    "node_critic")

    # ── الحافة الشرطية من الـ Critic ──
    g.add_conditional_edges(
        "node_critic",
        route_after_critic,
        {
            "node_writer"   : "node_writer",    # retry loop
            "node_finalizer": "node_finalizer",  # done ✓
        },
    )

    g.add_edge("node_finalizer", END)

    return g.compile()
