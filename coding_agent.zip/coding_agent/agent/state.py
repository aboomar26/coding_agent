# ============================================================
#  agent/state.py — تعريف الـ State اللي بيتنقل بين الـ nodes
# ============================================================

from typing import List, Optional
from typing_extensions import TypedDict
from langchain_core.messages import BaseMessage


class FileDiff(TypedDict):
    """تمثيل تغيير واحد على ملف — بيتعرض للمستخدم قبل التنفيذ"""
    filename   : str
    find_str   : str        # "" = إنشاء ملف جديد
    replace_str: str
    approved   : bool       # بيتملى بعد سؤال المستخدم


class CommandAction(TypedDict):
    """أمر shell واحد محتاج موافقة"""
    command    : str
    working_dir: str
    approved   : bool


class AgentState(TypedDict):
    # ---- المدخلات الأساسية ----
    messages        : List[BaseMessage]
    user_request    : str

    # ---- مخرجات كل node ----
    plan            : str
    context         : str

    # ---- Writer output ----
    raw_actions     : str           # JSON string من الـ Writer

    # ---- Approval gate ----
    file_diffs      : List[FileDiff]
    command_actions : List[CommandAction]

    # ---- Executor output ----
    last_tool_result: str

    # ---- Critic / control ----
    status          : str           # "running" | "success" | "retry"
    retry_count     : int
    critic_note     : str           # تفسير الـ Critic

    # ---- الإجابة النهائية ----
    final_answer    : str
