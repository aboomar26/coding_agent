#!/bin/bash
# ============================================================
#  setup.sh — إعداد البيئة من الصفر
# ============================================================

set -e

echo ""
echo "  🚀  إعداد Coding Agent..."
echo "  ══════════════════════════"

# ── Python dependencies ──
echo ""
echo "  📦  تثبيت الـ Python packages..."
pip install --quiet \
    langgraph \
    langchain \
    langchain-openai \
    langchain-core \
    langsmith \
    python-dotenv

echo "  ✓  Python packages جاهزة"

# ── Docker image ──
echo ""
echo "  🐳  تحميل Docker image..."
docker pull python:3.11-slim
echo "  ✓  Docker image جاهزة"

# ── Workspace ──
mkdir -p workspace
echo "  ✓  workspace/ جاهزة"

# ── __init__ files ──
touch agent/__init__.py
touch agent/nodes/__init__.py
touch llm/__init__.py
touch sandbox/__init__.py
echo "  ✓  Python packages structure جاهزة"

echo ""
echo "  ✅  كل حاجة جاهزة!"
echo ""
echo "  ابدأ vLLM server:"
echo "    python -m vllm.entrypoints.openai.api_server \\"
echo "      --model qwen2.5-coder:7b \\"
echo "      --port 8000"
echo ""
echo "  بعدين شغّل الـ agent:"
echo "    python agent.py"
echo ""
